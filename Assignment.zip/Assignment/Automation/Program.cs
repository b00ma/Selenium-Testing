﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace Automation
{
    class Program
    {
            static void Main(string[] args)
            {
                IWebDriver driver = new ChromeDriver(@"E:\Automation\Assignments");
                string url = "http://localhost:10221/Home/Login";
                driver.Navigate().GoToUrl(url);
                driver.Manage().Window.Maximize();
                Thread.Sleep(2000);

                IWebElement element1 = driver.FindElement(By.Name("Email"));  //Search the search bar(name=q)
                Thread.Sleep(2000);
                element1.SendKeys("poo@gmail.com" + Keys.Enter); //type automatically in search bar

                IWebElement element2 = driver.FindElement(By.Name("Password"));  //Search the search bar(name=q)
                Thread.Sleep(2000);
                element2.SendKeys("abcd1239");
                Thread.Sleep(2000);

                IWebElement element3 = driver.FindElement(By.Id("login"));
                Thread.Sleep(2000);
                element3.Click();

                Thread.Sleep(10000);
                driver.Quit();
            }
    }
}
